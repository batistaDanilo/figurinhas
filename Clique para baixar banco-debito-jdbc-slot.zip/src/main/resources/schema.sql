CREATE TABLE IF NOT EXISTS conta (
    id BIGINT PRIMARY KEY,
    nome TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS saldo (
    id BIGSERIAL PRIMARY KEY,
    conta_id BIGINT NOT NULL,
    slot SMALLINT NOT NULL,
    valor NUMERIC NOT NULL,
    UNIQUE (conta_id, slot),
    FOREIGN KEY (conta_id) REFERENCES conta(id)
);
INSERT INTO conta (id, nome) VALUES (1, 'Conta XPTO') ON CONFLICT DO NOTHING;
DO $$
BEGIN
  FOR i IN 0..9 LOOP
    INSERT INTO saldo (conta_id, slot, valor)
    VALUES (1, i, 1000.00)
    ON CONFLICT (conta_id, slot) DO NOTHING;
  END LOOP;
END $$;
