package com.exemplo.banco.controller;
import com.exemplo.banco.dto.DebitoRequest;
import com.exemplo.banco.service.DebitoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/debito")
public class DebitoController {
    private final DebitoService debitoService;
    public DebitoController(DebitoService debitoService) {
        this.debitoService = debitoService;
    }
    @PostMapping
    public ResponseEntity<?> debitar(@RequestBody DebitoRequest request) {
        try {
            debitoService.debitar(request.getContaId(), request.getValor());
            return ResponseEntity.ok("Débito realizado com sucesso.");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
