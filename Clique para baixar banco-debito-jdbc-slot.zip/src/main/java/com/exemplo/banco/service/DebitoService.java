package com.exemplo.banco.service;
import org.springframework.stereotype.Service;
import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.*;
import java.util.concurrent.ThreadLocalRandom;
@Service
public class DebitoService {
    private final DataSource dataSource;
    public DebitoService(DataSource dataSource) {
        this.dataSource = dataSource;
    }
    public void debitar(Long contaId, BigDecimal valor) {
        int slot = ThreadLocalRandom.current().nextInt(0, 10);
        try (Connection conn = dataSource.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT valor FROM saldo WHERE conta_id = ? AND slot = ? FOR UPDATE")) {
                ps.setLong(1, contaId);
                ps.setInt(2, slot);
                ResultSet rs = ps.executeQuery();
                if (!rs.next()) throw new RuntimeException("Slot de saldo não encontrado");
                BigDecimal saldoAtual = rs.getBigDecimal("valor");
                if (saldoAtual.compareTo(valor) < 0)
                    throw new RuntimeException("Saldo insuficiente no slot " + slot);
                try (PreparedStatement update = conn.prepareStatement(
                        "UPDATE saldo SET valor = valor - ? WHERE conta_id = ? AND slot = ?")) {
                    update.setBigDecimal(1, valor);
                    update.setLong(2, contaId);
                    update.setInt(3, slot);
                    update.executeUpdate();
                }
                conn.commit();
            } catch (Exception e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro no débito", e);
        }
    }
}
